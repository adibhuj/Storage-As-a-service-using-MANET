import os,time,MySQLdb,shutil

def getnewnode():
	print "Getting new node"

def retrywithnewpath(filename,path,usrid,fileid):
	print "updating buffer file with new path and moving to file_trig for retrying file transfer"
	header = "path+"+path+"\t"+usrid+"\t"+fileid.split("\n")[0]
	with open ("/home/cool/project18/server/buffer/"+filename,"r") as f:
		data = f.write()
	os.remove("/home/cool/project18/server/buffer/"+filename)
	data = data.split("\n")[1:]	
	dt = header
	for i in data:
		dt = dt+"\n"+i	
	with open ("/home/cool/project18/server/buffer/"+filename,"w") as f:
		f.write(dt)
	shutil.copyfile("/home/cool/project18/server/buffer/"+filename,"/home/cool/project18/trigger/file_trig/"+filename)
	
def readoldfilepath(fname):
	with open("/home/cool/project18/server/buffer/"+fname) as f:
		con=f.readline()
	fields=con.split("\t")
	print fields
	path=fields[0].split("+")
	path=path[1:]
	paths=""
	for i in path:
		print "paths: ",paths
		print "i: ",i
		paths=paths+i
		if(i!=path[-1]):
			paths=paths+"+"	
	print "oldpath in file is : ",paths
	return paths

def getpathfromdb(fname):
	try:
		sql = " select path from macrepo,file_part where f_p_name=\""+fname+"\" and macrepo.mac_addr=file_part.mac ;"
		cursor.execute(sql)
		rs = cursor.fetchall()
		print rs[0][0]
		return rs[0][0]
	except Exception as a:
		print a

while(True):
	fc=0
	fl=os.listdir("/home/cool/project18/trigger/file_ack/")
	fc=len(fl)		
	print "Total no of files present in file_ack dir "+str(fc)
	
	if fc>0:
		db = MySQLdb.connect("localhost","root","password","saas")
		cursor = db.cursor()
		for i in fl:
			with open("/home/cool/project18/trigger/file_ack/"+str(i),'r') as f:
				con=f.read()
			fields=con.split("\t")
			print fields
			fname=fields[0]
			
			if(fname=='Error'):
				print 'Error acknowledgement has arrived'
				fname=fields[1]
				mac=fields[2]
				print 'file for which error was generated is: ',fname
				print 'node which is unreachable is: ',mac
				print 'waiting for a while for path update to be taken'
				time.sleep(5)
				print "filename is: ",fname
				oldpath=readoldfilepath(fname)
				print "oldpath: ",oldpath
				dbpath=getpathfromdb(fname)
				print "dbpath: ",dbpath
				if(oldpath==dbpath):
					print "path was not updated need to get new node"
					getnewnode()
				else:	
					print "path was updated need to retry with new path"				
					retrywithnewpath(str(i),dbpath,fields[3],fields[4])
				'''
				try:
					sql = " select path from macrepo,file_part where f_p_name='bd_sample.txt.p_1' and macrepo.mac_addr=file_part.mac ;"
					
				except Exception as a:
					print a
				'''

			else:			
				mac=fields[1]
				uname=fields[2]
				fid=fields[3]
				print "filename is: ",fname
				print "mac is: ",mac
				print "uname is: ",uname
				print "fid is: ",fid
				
			
				try:
					sql = "insert into file_part values("+str(fid)+",\""+str(fname)+"\""+",\""+str(mac)+"\");"
					print sql
					cursor.execute(sql)	
					db.commit()
					os.remove("/home/cool/project18/server/buffer/"+fname)
					os.remove("/home/cool/project18/trigger/file_ack/"+str(i))
					#os.remove("erasure/"+fname)
				except Exception as a:
					print a
		db.close()
	time.sleep(5)
