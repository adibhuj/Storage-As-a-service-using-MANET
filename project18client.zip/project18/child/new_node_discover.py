import os,time

from funclib import *

def trigger_pth_chg_child():
	
	x = os.popen("create_ap --list-running | grep 'wl' |awk '{print $NF}'")
	inter_nm= x.read().split("\n")[0]
	
	x = os.popen("create_ap --list-clients "+inter_nm)
	cl = x.read().split("\n")
	if cl[0]!= "No clients connected":
		cl = cl[1:-1]
		with open("/home/cool/project18/update_path.txt","w") as f:
			f.read("Update u r path ,parent path is change ")
		for i in cl:
			send_path = "/home/cool/project18/update_path.txt cool@"+i[1]+":/home/cool/project18/trigger/server_init/"
			send_file(str(send_path))
		os.remove("/home/cool/project18/update_path.txt")

def new_node_discover():
	parent_mac =""
	while True:
		intrfc_name=os.popen("ip route show default |grep \'wl*\' | awk \'/default/ {print $5}\'")
		intrfc_nm=intrfc_name.read()
		intrfc_nm=intrfc_nm[0:-1]
		#print intrfc_nm
	
		x = os.popen("iwconfig "+intrfc_nm+" | grep 'Access Point:' | awk '{print $NF}'")
		current_parent_mac = x.read()
		print current_parent_mac

		if parent_mac != current_parent_mac:
			
			own_mac=getownmac()
			file_name = str(own_mac).replace(":","_")			
			with open("/home/cool/project18/"+file_name+".txt","w") as f:
				f.write(own_mac)
			parent_ip = get_parent_ip()
			
			
			send_path = "/home/cool/project18/"+file_name+".txt cool@"+parent_ip+":/home/cool/project18/trigger/node_discover"
			sendfile(send_path)
		
			if file_name+".txt" in os.listdir("/home/cool/project18/"):
				print "File deleted"
				os.remove("/home/cool/project18/"+file_name+".txt")
			if (parent_mac != ""):
				trigger_pth_chg_child()
			parent_mac =current_parent_mac
		
		time.sleep(30)

	#x = os.popen('sshpass -p \'password\' scp '+str("/home/cool/newproj/working/storage/"+rl[1])+' cool@'+parent_host_name+':/home/cool/newproj/working/retrieve/storage')
		

new_node_discover()
