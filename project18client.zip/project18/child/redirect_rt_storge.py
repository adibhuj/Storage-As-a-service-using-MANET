import os,time

from funclib import *

while True:
	fl=os.listdir("/home/cool/project18/trigger/retrieve/storage")
	fc=len(fl)		
	print "Total no of files present in ack dir "+str(fc)
	if fc>0:
		for x in range(fc):
			fname=fl[x]
			store_filename="/home/cool/project18/trigger/retrieve/storage/"+fname
			parentip=get_parent_ip()
			pathcmd=store_filename+' cool@'+parentip+':/home/cool/project18/trigger/retrieve/storage/'
			sendfile(pathcmd)
			s=os.popen("rm "+store_filename)
			x=s.read()
			print x
				
	time.sleep(2)
