import os
from funclib import *
from new_node_discover import trigger_pth_chg_child

def check_parent_pth_chg():
	while True:
		fl = os.listdir("/home/cool/project18/trigger/server_init")
		fc = len(fl)	
		if fc== 0 :
			print "Path of parent is not change........."		
			time.sleep(10)
		
		else :
			with open("/home/cool/project18/trigger/server_init/"+fl[0],"r") as f:
				print f.read()
			os.remove("/home/cool/project18/trigger/server_init/"+fl[0])
			
			own_mac=getownmac()
			file_name = str(own_mac).replace(":","_")			
			with open("/home/cool/project18/"+file_name+".txt","w") as f:
				f.write(own_mac)
			parent_ip = get_parent_ip()
			
			send_path = "/home/cool/project18/"+file_name+".txt cool@"+parent_ip+":/home/cool/project18/trigger/node_discover"
			sendfile(send_path)
		
			if file_name+".txt" in os.listdir("/home/cool/project18/"):
				print "File deleted"
				os.remove("/home/cool/project18/"+file_name+".txt")
			
			trigger_pth_chg_child()			
	
check_parent_pth_chg()
