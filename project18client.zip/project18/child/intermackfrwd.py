import os,time

from funclib import sendfile,get_parent_ip
'''
def sendfile(pathcmd):	
	x = os.popen(' sshpass -p \'password\' scp '+pathcmd)
	f = x.read()
	print f	
'''

while True:
	fl=os.listdir("/home/cool/project18/trigger/file_ack/")
	fc=len(fl)		
	print "Total no of files present in file_ack dir "+str(fc)
	if fc>0:
		for x in range(fc):
			fname=fl[x]
			ackfilename="/home/cool/project18/trigger/file_ack/"+fname
			parentip=get_parent_ip()
			pathcmd=ackfilename+' cool@'+parentip+':/home/cool/project18/trigger/file_ack/'
			sendfile(pathcmd)
			os.remove(ackfilename)
			'''s=os.popen("rm "+ackfilename)
			x=s.read()
			print x
			'''	
	time.sleep(5)
