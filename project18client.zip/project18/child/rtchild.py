import os,time
from funclib import *

while True:
	fl = os.listdir("/home/cool/project18/trigger/retrieve/rt/")
	fc = len(fl)	
	if fc== 0 :
		print "NO request for retriving the file........."		
		time.sleep(10)
		
	else :
		while(fc>0):
			print "Request for file................"
			with open ("/home/cool/project18/trigger/retrieve/rt/"+str(fl[fc-1]),"r") as f:	
				rl = f.read()
			rl = rl.split("\n")
			path = rl[0].split("+")
			if len(path)==1 : 
				print path
			
				if path[0]==getownmac() :
					print "correct node"
					store_file = os.listdir("/home/cool/project18/files/store_file/")
					if rl[1] in store_file :
					
						#get parent host name and then send file to parent store in storage -----------------
						parent_host_name=get_parent_ip()
						x = os.popen('sshpass -p \'password\' scp '+str("/home/cool/project18/files/store_file/"+rl[1])+' cool@'+parent_host_name+':/home/cool/project18/trigger/retrieve/storage') #sending file part to server	
						f = x.read()
						print f 
				
				
					else :
						print "file is not present"
				else :
						print "Wrong node"
			else :
			
				#get the ip of path[0]----------------------------------
				
				child_ip=mactoip(path[1])
				if child_ip=="Null":
					print "Req. node is not present"
					#with open("np"+
					
				else :
					print "child_ip : "+child_ip
					print "File for :"+path[1]
					new_path=path[1]
					for i in range(2,len(path)) :
						new_path= new_path+"+"+path[i]
					print "new path"+new_path
					#delete file "getting_file"		
					if fl[fc-1].split(".")[0] in os.listdir("/home/cool/project18/trigger/retrieve/rt"):
						os.remove("/home/cool/project18/trigger/retrieve/rt/"+fl[fc-1].split(".")[0])
				
					with open("/home/cool/project18/trigger/retrieve/rt/"+str(fl[fc-1]),"w")as f:
						f.write(new_path+"\n")
						f.write(rl[1])
					with open("/home/cool/project18/trigger/retrieve/rt/"+str(fl[fc-1]),"r") as f:
						print "file contain"
						print "file name : ",str(fl[fc-1])
						print f.read()
				
					#send the file 'getting_file' to its child node -------------------
					x = os.popen('sshpass -p \'password\' scp '+str("/home/cool/project18/trigger/retrieve/rt/"+str(fl[fc-1]))+' cool@'+child_ip+':/home/cool/project18/trigger/retrieve/rt') #sending file getting_file to child	
					f = x.read()
							
				
			#delete file "getting_file"

			
			if fl[fc-1] in os.listdir("/home/cool/project18/trigger/retrieve/rt"):
				print "delete from retrieve/rt"
				os.remove("/home/cool/project18/trigger/retrieve/rt/"+str(fl[fc-1]))
			fc = fc-1
			


	
