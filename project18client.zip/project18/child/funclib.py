import os,time

def getownmac():
	intrfc_name=os.popen("ip route show default |grep \'wl*\' | awk \'/default/ {print $5}\'")
	intrfc_nm=intrfc_name.read()
	intrfc_nm=intrfc_nm[0:-1]
	#print intrfc_nm

	mac=os.popen("cat /sys/class/net/"+intrfc_nm+"/address")
	mac_addr=mac.read()
	mac_addr=mac_addr[0:-1]
	print mac_addr
	return mac_addr

def filechange(filename,newheader):

	with open(filename) as f:
		cont=f.read()
	print "file contents are: "
	print cont

	fcont=cont.split("\n")
	ncont=newheader+"\n"+fcont[1]
	fcont=fcont[2:]
	
	for i in fcont:
		ncont=ncont+"\n"+i

	with open(filename,'w') as f:
		f.write(ncont)

	with open(filename) as f:
		cont=f.read()
	print "final file contents are: "
	print cont

def get_parent_ip():
	print "calling get_parent_ip"
	host = os.popen("hostname -I|awk '{print $NF}'")
	thost = host.read()
	host = thost.split('.')
	host = host[0:-1]
	server_host = ""
	for i in host:
		server_host += i + '.'
	server_host += '1'
	print server_host
	return server_host

def sendfile(pathcmd):	
	print "calling sendfile"
	x = os.popen(' sshpass -p \'password\' scp '+pathcmd)
	f = x.read()
	print f	

def mactoip(mactosend):
	x =  os.popen('create_ap --list-client wlp2s0')
	f = x.read()
	list = f.split('\n')
	z = 0
	ip=""
	for i in list:
		if(z!= 0 and z < (len(list) - 1)):
			ls = i.split()
			print ls[1]+" "+ls[0]
			#lso=str('bc:d1:d3:92:78:4d')
			
			if(ls[0]==mactosend):
				ip=str(ls[1])
		z+=1                
	#print "Obtained immediate client ip "
	if ip=="":
		return "Null"
	else:	
		return ip	

def newheaderform(oldpth):
	macfrconv=oldpth[1]
	headr="path"
	pth=oldpth[1:]
	for i in pth:
		headr=headr+"+"+i
	print "new header is "	
	print headr
	return headr




