import shutil,os,time
from funclib import *


while True:					
		fl=os.listdir("/home/cool/project18/trigger/file_trig/")
		global fc
		fc=len(fl)		
		print "Total no of files present in trig dir "+str(fc)
		
		if fc>0:
			for x in range(fc):
				fname="/home/cool/project18/trigger/file_trig/"+str(fl[x])
				nm=fl[x]
				with open(fname,"r") as f:
						cont=f.read()
			
				lst=cont.split("\n")
				print "first line is:: ",lst[0]
				ilst = lst[0].split("\t")				
				flf=ilst[0].split("+")
				print "first field is:: ",flf[0]
				print "File id "+ilst[2]
			
				oldpath=flf[1:]
				pathlen=len(oldpath)
				print oldpath
			
				if flf[0]=="path":
					print "Header is present "
					mymac=getownmac()
					if(oldpath[0]==mymac and pathlen>=1):
						print "correct node"
						if(pathlen==1):
							print "file is for me"					
							src = fname
							dest= "/home/cool/project18/files/store_file/"
							shutil.move(src,dest)
							#sending acknowledgement to server
							ackfilename="ack"+"_"+nm
							with open(ackfilename,'w') as f:
								f.write(nm+"\t"+mymac+"\t"+ilst[1]+"\t"+ilst[2])
							parentip=get_parent_ip()
							pathcmd=ackfilename+' cool@'+parentip+':/home/cool/project18/trigger/file_ack/'
							sendfile(pathcmd)
							s=os.popen("rm "+ackfilename)
							x=s.read()
							print x
							 
						else:
							print "file need to be forwarded"
							newheadr=newheaderform(oldpath)
							newheadr = newheadr+"\t"+ilst[1]+"\t"+ilst[2]
							mactosend=oldpath[1]
							ip=mactoip(mactosend)
							if(ip=="Null"):
								print "Node doesn't exist"
							else:
								print "Editing the file header before sending"
								filechange(fname,newheadr)
								print "sending encoded file to client"+str(ip)
								pathcmd=fname+' cool@'+ip+':/home/cool/project18/trigger/file_trig/'
								sendfile(pathcmd)
								os.remove(fname)
						
					else:
						print "wrong node and hence discarding the file"
						os.remove(fname)
					#add function
				
				else:
					print "Header is not present and hence discarding the file"
					os.remove(fname)
				'''	src = "/home/cool/newproj/working/files/trig/"+fl[0]
					dest= "/home/cool/newproj/working/files/store_file/"
					shutil.move(src,dest)
				'''
		time.sleep(3)
