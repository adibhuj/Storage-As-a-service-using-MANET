import os,time
from funclib import mactoip,getownmac,get_parent_ip,sendfile

def redirect_child_mac():
	p="/home/cool/project18/trigger/node_discover"

	while True:
		fl = os.listdir(p)
		fc = len(fl)	
		if fc== 0 :
			print "No file is present for redirection........."		
			time.sleep(10)
		
		else :
		
			for i in fl:
				with open(p+"/"+i,"r") as f:
					child_mac = f.read()

				os.remove(p+"/"+i)		
				
				new_path = str(getownmac())+"+"
				new_path = new_path+str(child_mac)
									
				with open(p+"/"+i,"w") as f:
					f.write(new_path)
			
				parent_ip = get_parent_ip()
				
				send_path = p+"/"+i+" cool@"+parent_ip+":/home/cool/project18/trigger/node_discover"
				sendfile(send_path)
			
				os.remove(p+"/"+i)		
			

redirect_child_mac()
