import os,time,MySQLdb

def getnewnode(mac,fid):
	macs=getfilepartsmacfromdb(fid)
	macs.append(mac)
	n=len(macs)+3
	print "Getting new node"
	nmacs=getnewnodes(n)
	nodes = [x for x in nmacs if x not in macs]
	print "new nodes obtained are : ",nodes
	path=getpathofnode(nodes[0])
	print "obtained path is: ",path	
	return path

def getpathofnode(mac):
	path=''
	print "fun mac: ",mac
	try:
		sql = "select path from macrepo where mac_addr=\""+str(mac)+"\";"
		cursor.execute(sql)
		rs = cursor.fetchall()
		print rs
		path=rs[0][0]
	except Exception as a:
		print a
	
	return path


def getfilepartsmacfromdb(fid):
	maclist=[]
	try:
		sql = "select mac from file_part where f_id=3;"
		cursor.execute(sql)
		rs = cursor.fetchall()
		
		print rs
		for i in rs:
			maclist.append(i[0])
		print "maclist is : ",maclist
	except Exception as a:
		print a
	return maclist

def getnewnodes(n):
	
	qry="select mac_addr from macrepo order by length(path) limit "+str(n)+";"
	#select *from macrepo order by length(path) limit 4;
	cursor.execute(qry)
	rs=cursor.fetchall()
	macs=[]
	for i in rs:
		macs.append(i[0])

	print macs
	return macs

db = MySQLdb.connect("localhost","root","password","saas")
cursor = db.cursor()
mac="e8:4e:06:2f:db:65"
fid=3
getnewnode(mac,fid)


