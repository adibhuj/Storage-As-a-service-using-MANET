import shutil,os,time
from funclib import *


while True:					
		fl=os.listdir("/home/cool/project18/trigger/file_trig/")
		global fc
		fc=len(fl)		
		print "Total no of files present in file_trig dir "+str(fc)
		
		if fc>0:
			for x in range(fc):
				fname="/home/cool/project18/trigger/file_trig/"+str(fl[x])
				nm=fl[x]
				with open(fname,"r") as f:
						cont=f.read()
			
				lst=cont.split("\n")
				
				print "first line is:: ",lst[0]
				ilst=lst[0].split("\t")
				print " ilst is : ",ilst
				flf=ilst[0].split("+")
				print "first field is:: ",flf[0]
				print "userid is : ",ilst[1]
				print "file id is: ",ilst[2]
				if flf[0]=="path":
					print "Header is present "
					path=flf[1:]
					#pathlen=len(oldpath)
					print path[0]
					
					ip=mactoip(path[0])
					print "got ip as: ",ip
					if(ip=="Null"):
						print "Node doesn't exist and hence discarding the file"
						ackfilename="ack"+"_"+nm
						with open(ackfilename,'w') as f:
							f.write("Error\t"+nm+"\t"+flf[-1]+"\t"+ilst[1]+"\t"+ilst[2])
						shutil.move(ackfilename,"/home/cool/project18/trigger/file_ack/")						
						print "moving file from trig to buffer of server"
						shutil.move(fname,"/home/cool/project18/server/buffer/")					
						
						#os.remove(fname)					
						
					else:
						print "sending encoded file to client"+str(ip)
						pathcmd=fname+' cool@'+ip+':/home/cool/project18/trigger/file_trig/'
						sendfile(pathcmd)
						print "file sent to trig of client"
						print "moving file from trig to buffer of server"
						shutil.move(fname,"/home/cool/project18/server/buffer/")					
						#s=os.popen("rm "+fname)
						#x=s.read()
						#print x
				else: 
					print "header is not present hence discarding the file"	
					os.remove(fname)
								

		time.sleep(3)
