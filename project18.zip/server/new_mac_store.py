import MySQLdb,os,time


def new_mac_store():
	p="/home/cool/project18/trigger/node_discover/"
	# Open database connection
	db = MySQLdb.connect("localhost","root","password","saas" )

	# prepare a cursor object using cursor() method
	cursor = db.cursor()
	while True:
		fl = os.listdir(p)
		fc = len(fl)	
		print "fl: ",fl
		if fc== 0 :
			print "No new mac file present for path updation........."		
			
		
		else :		
			for i in fl:
				print "i: ",i
				with open(p+i,"r") as f:
					new_child_path = f.read().split("\n")[0]
				child_mac=new_child_path.split("+")[-1]
				print "new child path: ",new_child_path
				sql = "select mac_addr from macrepo where mac_addr=\""+str(child_mac)+"\";"
				print sql							
				cursor.execute(sql)
				rs = cursor.fetchall()
				if not rs:
					sql="insert into macrepo values(\""+str(child_mac)+"\",\""+str(new_child_path)+"\");"
					print sql
					cursor.execute(sql)
					db.commit()
				else:
					sql = "update macrepo set path=\""+str(new_child_path)+"\" where mac_addr=\""+str(child_mac)+"\";"
					print sql
					cursor.execute(sql)
					db.commit()
				os.remove(p+i)
		time.sleep(5)

new_mac_store()
