#!usr/bin/python

import os
from file_ecc import EncodeFile,DecodeFiles

if __name__ == '__main__':
    filename = raw_input("Enter the file name to be retrieved from your clients...")
    print
    #prefix="/retrieved/"+filename
    prefix = "/home/cool/newproj/working/erasure/recv/abc.txt"
    decList = map(lambda x: prefix + '.p_' + `x`,[0,1,2,3])
    print decList
    for i in decList:
        if os.path.exists(i):
            print i
        else:
            print "File ",i," not found"
            del decList[decList.index(i)]
    decodedFile = './a_dec.txt'
    print decList
    DecodeFiles(decList, decodedFile)

print "file decoded successfully"
