import shutil,os,time
def getownmac():
	intrfc_name=os.popen("ip route show default |grep \'wl*\' | awk \'/default/ {print $5}\'")
	intrfc_nm=intrfc_name.read()
	intrfc_nm=intrfc_nm[0:-1]
	#print intrfc_nm

	mac=os.popen("cat /sys/class/net/"+intrfc_nm+"/address")
	mac_addr=mac.read()
	mac_addr=mac_addr[0:-1]
	print mac_addr
	return mac_addr

def filechange(filename,newheader):

	with open(filename) as f:
		cont=f.read()
	print "file contents are: "
	print cont

	fcont=cont.split("\n")
	ncont=newheader+"\n"+fcont[1]
	fcont=fcont[2:]
	
	for i in fcont:
		ncont=ncont+"\n"+i

	with open(filename,'w') as f:
		f.write(ncont)

	with open(filename) as f:
		cont=f.read()
	print "final file contents are: "
	print cont

def get_parent_ip():
    host = os.popen("hostname -I|awk '{print $2}'")
    thost = host.read()
    host = thost.split('.')
    host = host[0:-1]
    server_host = ""
    for i in host:
        server_host += i + '.'
    server_host += '1'
    return server_host



def newheaderform(oldpth):
	macfrconv=oldpath[1]
	headr="path"
	pth=oldpath[1:]
	for i in pth:
		headr=headr+"+"+i
	print "new header is "	
	print headr
	return headr

def sendfile(pathcmd):	
	x = os.popen(' sshpass -p \'password\' scp '+pathcmd)
	f = x.read()
	print f	


def mactoip(mactosend):
	x =  os.popen('create_ap --list-client wlp3s0f0')
	f = x.read()
	list = f.split('\n')
	z = 0
	ip=""
	for i in list:
		if(z!= 0 and z < (len(list) - 1)):
			ls = i.split()
			print ls[1]+" "+ls[0]
			#lso=str('bc:d1:d3:92:78:4d')
			
			if(ls[0]==mactosend):
				ip=str(ls[1])
		z+=1                
	#print "Obtained immediate client ip "
	if ip=="":
		return "Null"
	else:	
		return ip	

while True:					
		fl=os.listdir("/home/cool/newproj/working/files/trig/")
		global fc
		fc=len(fl)		
		print "Total no of files present in trig dir "+str(fc)
		
		if fc>0:
			for x in range(fc):
				fname="/home/cool/newproj/working/files/trig/"+str(fl[x])
				nm=fl[x]
				with open(fname,"r") as f:
						cont=f.read()
			
				lst=cont.split("\n")
				print "first line is:: ",lst[0]
				flf=lst[0].split("+")
				print "first field is:: ",flf[0]
						
			
				oldpath=flf[1:]
				pathlen=len(oldpath)
				print oldpath
			
				if flf[0]=="path":
					print "Header is present "
					mymac=getownmac()
					if(oldpath[0]==mymac and pathlen>=1):
						print "correct node"
						if(pathlen==1):
							print "file is for me"					
							src = fname
							dest= "/home/cool/newproj/working/files/store_file/"
							shutil.move(src,dest)
							#sending acknowledgement to server
							ackfilename="ack"+"_"+nm
							with open(ackfilename,'w') as f:
								f.write(nm+"\t"+mymac)
							parentip=get_parent_ip()
							pathcmd=ackfilename+' cool@'+parentip+':/home/cool/newproj/working/files/ack/'
							sendfile(pathcmd)
							s=os.popen("rm "+ackfilename)
							x=s.read()
							print x
							 
						else:
							print "file need to be forwarded"
							newheadr=newheaderform(oldpath)
							mactosend=oldpath[1]
							ip=mactoip(mactosend)
							if(ip=="Null"):
								print "Node doesn't exist"
							else:
								print "Editing the file header before sending"
								filechange(fname,newheadr)
								print "sending encoded file to client"+str(ip)
								pathcmd=fname+' pi@'+ip+':/home/pi/newproj/files/trig/'
								sendfile(pathcmd)
								s=os.popen("rm "+fname)
								x=s.read()
								print x
						
					else:
						print "wrong node and hence discarding the file"
					#add function
				
				else:
					print "Header is not present and hence discarding the file"
						
				'''	src = "/home/cool/newproj/working/files/trig/"+fl[0]
					dest= "/home/cool/newproj/working/files/store_file/"
					shutil.move(src,dest)
				'''
		time.sleep(3)
