import os,time,MySQLdb

fname='abc.txt.p_0'
print fname
f=fname.split('')
print f
fn=f[0]+f[1]

print fn
