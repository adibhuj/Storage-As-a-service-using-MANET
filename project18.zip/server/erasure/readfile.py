
filename="abc.txt.p_0"

with open(filename) as f:
	cont=f.read()
print "file contents are: "
print cont+"\n"
path="path+e8:4e:06:2f:dd:55+e8:4e:06:2f:fa:cd+3c:91:57:f6:7f:52"
with open("temp_file.txt",'w') as f:
	f.write(path+"\n")
	f.write(cont)

with open("temp_file.txt") as f:
	cont=f.read()
print "temp file contents are: "
print cont

with open(filename,'w') as f:
	f.write(cont)

with open(filename) as f:
	cont=f.read()
print "new file contents are: "
print cont

fcont=cont.split("\n")
npath=fcont[0]
ncont=fcont[1]
fcont=fcont[2:]

for i in fcont:
	ncont=ncont+"\n"+i

with open(filename,'w') as f:
	f.write(ncont)

with open(filename) as f:
	cont=f.read()
print "final file contents are: "
print cont




