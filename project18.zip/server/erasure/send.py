# ! /usr/bin/python


import sys
import os
from file_ecc import EncodeFile
sys.path.append('.')

#from main_server import NodeDiscovery

args = [arg for arg in sys.argv]
filename = args[1]
n = int(args[2])
k = int(args[3])
prefix = os.path.abspath(filename)
if n > 256 or k >= n or k <= 0:
    print "not right"
names = EncodeFile(filename, prefix, n, k)


#nd = NodeDiscovery(n,filename)
