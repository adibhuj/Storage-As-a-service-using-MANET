import os,time,shutil
import threading, time, os
import MySQLdb
from macdirlookup import my_threaded_func,get_client_list
from rtserver import rtserver
from funclib import mactoip
def getcountfromdb():
	db = MySQLdb.connect("localhost","root","password","saas")
	cursor = db.cursor()

	try:
		sql = "select count(mac_addr) from macrepo;"
		print sql
		cursor.execute(sql)	
		rs=cursor.fetchall()
		#print rs[0][0]
		return rs[0][0]
	except Exception as a:
		print "error while fetching count from database"



def getpathsforheaders(n):
	db = MySQLdb.connect("localhost","root","password","saas")
	cursor = db.cursor()
	qry="select path from macrepo order by length(path);"
	#select *from macrepo order by length(path) limit 4;
	cursor.execute(qry)
	rs=cursor.fetchall()
	paths=[]
	for i in range(n):
		paths.append(rs[i][0])
	'''for i in rs:
		paths.append(i[0])
	'''	
	print "printing the paths list"
	print paths
	return paths


def erasure_opn(fname,n,k):
	x=os.popen("python erasure/send.py "+fname+" "+str(n)+" "+str(k))
	s=x.read()
	print s
	encodedfilenames=[]
	for i in range(n):
		fn=fname+".p_"+str(i)
		encodedfilenames.append(fn)
	print "Encoded filenames are",encodedfilenames
	'''with open(encodedfilenames[0]) as f:
		cont=f.read()
	print cont'''
	return encodedfilenames

def setfileindex(f_name,uid):
	db = MySQLdb.connect("localhost","root","password","saas")
	cursor = db.cursor()
	fn=f_name.split("/")
	print fn[-1]
	#insert into file_index(f_name,u_id) values('g','c');
	try:
		sql = "insert into file_index(f_name,u_id) values(\""+str(fn[-1])+"\",\""+uid+"\");"
		print sql
		cursor.execute(sql)	
		db.commit()
	except Exception as a:
		print a

def getfileindex(f_name,uid):
	db = MySQLdb.connect("localhost","root","password","saas")
	cursor = db.cursor()
	fn=f_name.split("/")
	print fn[-1]
	#insert into file_index(f_name,u_id) values('g','c');
	try:
		sql = "select f_id from file_index where f_name=\""+str(fn[-1])+"\" and u_id=\""+uid+"\";"
		print sql
		cursor.execute(sql)
		rs=cursor.fetchall()
		fid=rs[0][0]
		return fid
	except Exception as a:
		print a
		
	
		
def copyfileforstoreopn(fpath,uname):
	fname=fpath.split("/")
	print fname[-1]
	newpathname='/home/cool/project18/server/files/'+uname+'_'+fname[-1]
	shutil.move(fpath,newpathname)
	print 'file moved to server/files dir'
	return newpathname

def storefilecase():
	print "enter the username"
	uid=raw_input()
	print "enter the name of the file you want to store(Full path if not present in cwd)"
	fpath=str(raw_input())
	
	if os.path.exists(fpath):
		#print "enter value of n and k"
		n=2
		k=1
		fname=copyfileforstoreopn(fpath,uid)
		setfileindex(fname,uid)
		f_id=getfileindex(fname,uid)
		enfilenames=erasure_opn(fname,n,k)
		print "discover nodes for storage"
		#print "Main started"
		#global client_list_ip
		x=int(getcountfromdb())
		if(x>=n):
			print "No of nodes required for storage condition is satisfied"
			paths=getpathsforheaders(n)
			#adding headers to encoded files
			for i in range(n):
				with open(enfilenames[i]) as f:
					cont=f.read()
				#print "file contents are: "
				#print cont+"\n"
				path=paths[i]
				with open(enfilenames[i],'w') as f:
					f.write("path+"+path+"\t"+str(uid)+"\t"+str(f_id)+"\n")
					f.write(cont)
				
				src = enfilenames[i]
				print "src : ",src
				dest= "/home/cool/project18/trigger/file_trig/"
				print "copying file to file_trig"		
				x=os.popen("cp "+str(src)+" "+str(dest))
				f=x.read()
				print f
				#shutil.move(src,dest)
				#waiting for acknowledgement function need to be written
			
		else:
			print "No of nodes required for storage condition is not satisfied"
			print "Cannot go for storage"


				
		

	else:
		print "file doesnt exist "


'''
def getfileid(flname,uid):
	db = MySQLdb.connect("localhost","root","password","saas")
	cursor = db.cursor()
	qry="select f_id from file_index where f_name=\'"+flname+"\' and u_id=\'"+uid+"\';"
	#select *from macrepo order by length(path) limit 4;
	cursor.execute(qry)
	rs=cursor.fetchall()
	return rs[0][0]
'''		
def retrievefilecase():
	rtserver()	
		
	



ch=1
while(ch!=0):
	print "Menu\n1.Store a file\n2.Retrieve a file\n0.Exit\n"
	ch=int(input())
	if(ch==1):
		print "store operation"
		storefilecase()
	elif(ch==2):
		print "retrieve operation"
		retrievefilecase()
	
