import MySQLdb,shutil,os,time
from funclib import mactoip

def rtserver():
	uid = raw_input("Enter the user name :")	
	file_name = raw_input("Enter the name of file u want to retrieve :")	
	db = MySQLdb.connect("localhost","root","password","saas")
	cursor = db.cursor()
	sql = "select f_id from file_index where f_name=\""+file_name+"\" and u_id=\""+str(uid)+"\";"
	cursor.execute(sql)
	rs = cursor.fetchall()

	F_id = rs[0][0]# getting F_id from file_index table
	print "F_id :"+str(F_id)

	sql = "select f_p_name,mac from file_part where f_id="+str(F_id)+";"

	cursor.execute(sql)
	rs=cursor.fetchall()
	#rs[0][0]=F_P_name rs[0][1]=mac
	print rs
	
	for i in rs:
		#i[0] file part name and i[1]=mac node 
		fn = "/home/cool/project18/trigger/retrieve/rt/req_"+i[0]
		print "\n\n Print i :"
		print i
		sql = "select path from macrepo where mac_addr=\'"+i[1]+"\'"
		cursor.execute(sql)
		path = cursor.fetchall()
		#print path
		path = path[0][0] # getting path from mac_index
		mac = path.split("+")[0]
	
		#print "MAC " + mac+"\tPath"+path	
		#delete alerdy created getting_file
		#if "getting_file.txt" in os.listdir("/home/cool/newproj/working/retrieve"):
		#	os.remove("/home/cool/newproj/working/retrieve/getting_file.txt")

		with open (fn,"w") as f:
			f.write(path+"\n")
			f.write(i[0])
		# get ip from "mac"	
		child_ip=mactoip(mac)	
		# send file getting_file to that ip and also delete file 'getting_file'------------------------------
		
		x = os.popen('sshpass -p \'password\' scp '+str(fn)+' cool@'+child_ip+':/home/cool/project18/trigger/retrieve/rt') #sending getting file to child	
		f = x.read()
		print f
		print "File sent to child"
		with open(fn,"r") as f:
			print "file contain"
			print "file name : ",fn
			print f.read()
		
		if fn.split("/")[-1] in os.listdir("/home/cool/project18/trigger/retrieve/rt"):
			print "Deleting file"+fn.split(".")[0]		
			os.remove(fn)


	#wait for file to get from client
	flag = False
	time_out=0
	while flag!=True:					
		fl=os.listdir("/home/cool/project18/trigger/retrieve/storage")
		fc=len(fl)
		print "Total no of files present in search dir "+str(fc)
		if fc==2:
			flag=True
		elif (time_out==20):
			flag=True
		else:			
			time.sleep(2)    			
			time_out +=1
			print "File not present"
	


	#move all file from incoming to retrieve
	
	#source = "/home/cool/newproj/working/retrieve/storage/*."
	#dest = "/home/cool/newproj/working/retrieve/final/"

	#shutil.move(source,dest)
	#call to ersure library--------------------------------------

#rtserver()





	
			



