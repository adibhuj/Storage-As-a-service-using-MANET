import os,time,MySQLdb

while(True):
	fc=0
	fl=os.listdir("/home/cool/project18/trigger/file_ack/")
	fc=len(fl)		
	print "Total no of files present in file_ack dir "+str(fc)
	
	if fc>0:
		db = MySQLdb.connect("localhost","root","password","saas")
		cursor = db.cursor()
		for i in fl:
			with open("/home/cool/project18/trigger/file_ack/"+str(i),'r') as f:
				con=f.read()
			fields=con.split("\t")
			print fields
			fname=fields[0]
			mac=fields[1]
			print "filename is: ",fname
			print "mac is: ",mac
			
			try:
				sql = "insert into file_part values(1,\""+str(fname)+"\""+",\""+str(mac)+"\");"
				print sql
				cursor.execute(sql)	
				db.commit()
				os.remove("/home/cool/project18/trigger/file_ack/"+str(i))
				#os.remove("erasure/"+fname)
			except Exception as a:
				print a
		db.close()
	time.sleep(5)
