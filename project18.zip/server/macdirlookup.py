import time, os



def get_client_list():
	
	x =  os.popen('create_ap --list-client wlp3s0f0')
	f = x.read()

	list = f.split('\n')
	z = 0
	client_list_ip = []
	client_list_mac = []
	for i in list:
		if z != 0 and z < (len(list) - 1):
		        ls = i.split()
			global client_list_ip
			client_list_ip.append(ls[1])
			
			print "\nMy Clients :"
		        print client_list_ip
		z+=1                
	print "Obtained immediate client list "
	return client_list_ip

def my_threaded_func(arg):
	print "value of arg is "+str(arg)
	flag = False
	time_out=(int(arg))*10
	localcounter=0
	conditionval=len(client_list_ip)
	while flag!=True:					
		fl=os.listdir("/home/cool/newproj/mac")
		global fc
		fc=len(fl)
		print "Total no of files present in mac dir "+str(fc)
		if fc>=conditionval:
			flag=True
		elif (localcounter==time_out):
			flag=True
		else:			
			time.sleep(2)    			
			localcounter+=1



	if(localcounter==time_out):
		print "Daemon ended due to timeout"
	print "Creating file with combined mac files"
		
	filename="macaddrlist.txt"	
	if os.path.exists(filename):
		s=os.popen("rm macaddrlist.txt")
		f=s.read()
		print f
				
	with open(filename,'a') as file:
		
		for i in fl:
			with open("/home/cool/newproj/mac/"+i,'r') as file:
				readdata=file.read()
			if os.path.exists(filename):
				with open(filename,'a') as file:
					file.write(readdata)
			else:
				with open(filename,'w') as file:
					file.write(readdata)
	
	x = os.popen('chmod 777 '+filename) 	
	f = x.read()
	print f

