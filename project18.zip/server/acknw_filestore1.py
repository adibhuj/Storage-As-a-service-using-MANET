import os,time,MySQLdb,shutil

def getnewnode(mac,fid):
	macs=getfilepartsmacfromdb(fid)
	macs.append(mac)
	n=len(macs)+3
	print "Getting new node"
	nmacs=getnewnodes(n)
	nodes = [x for x in nmacs if x not in macs]
	print "new nodes obtained are : ",nodes
	path=getpathofnode(nodes[0])
	print "obtained path is: ",path	
	return path

def getpathofnode(mac):
	path=''
	print "fun mac: ",mac
	try:
		sql = "select path from macrepo where mac_addr=\""+str(mac)+"\";"
		cursor.execute(sql)
		rs = cursor.fetchall()
		print rs
		path=rs[0][0]
	except Exception as a:
		print a
	
	return path


def getfilepartsmacfromdb(fid):
	maclist=[]
	try:
		sql = "select mac from file_part where f_id="+str(fid)+";"
		cursor.execute(sql)
		rs = cursor.fetchall()
		
		print rs
		for i in rs:
			maclist.append(i[0])
		print "maclist is : ",maclist
	except Exception as a:
		print a
	return maclist

def getnewnodes(n):
	
	qry="select mac_addr from macrepo order by length(path) limit "+str(n)+";"
	#select *from macrepo order by length(path) limit 4;
	cursor.execute(qry)
	rs=cursor.fetchall()
	macs=[]
	for i in rs:
		macs.append(i[0])

	print macs
	return macs

def retrywithnewpath(filename,path,usrid,fileid):
	print "updating buffer file with new path and moving to file_trig for retrying file transfer"
	header = "path+"+path+"\t"+str(usrid)+"\t"+fileid.split("\n")[0]
	with open ("/home/cool/project18/server/buffer/"+filename,"r") as f:
		data = f.read()
	os.remove("/home/cool/project18/server/buffer/"+filename)
	data = data.split("\n")[1:]	
	dt = header
	for i in data:
		dt = dt+"\n"+i	
	with open ("/home/cool/project18/server/buffer/"+filename,"w") as f:
		f.write(dt)
	shutil.move("/home/cool/project18/server/buffer/"+filename,"/home/cool/project18/trigger/file_trig/"+filename)
	

def readoldfilepath(fname):
	with open("/home/cool/project18/server/buffer/"+fname) as f:
		con=f.readline()
	fields=con.split("\t")
	print fields
	path=fields[0].split("+")
	path=path[1:]
	paths=""
	for i in path:
		print "paths: ",paths
		print "i: ",i
		paths=paths+i
		if(i!=path[-1]):
			paths=paths+"+"	
	print "oldpath in file is : ",paths
	return paths

def delete_entryfrm_macrepo(mac):
	try:
		sql = "delete from macrepo where mac_addr=\""+str(mac)+"\";"
		print sql
		cursor.execute(sql)	
		db.commit()
		print "Deleted record of mac "+str(mac)+" from macrepo"
	except Exception as a:
		print a

def getpathfromdb(mac):
	try:
		#sql = " select path from macrepo,file_part where f_p_name=\""+fname+"\" and macrepo.mac_addr=file_part.mac ;"
		sql = " select path from macrepo where mac_addr=\""+str(mac)+"\";"
		print sql
		cursor.execute(sql)
		rs = cursor.fetchall()
		print rs[0][0]
		return rs[0][0]
	except Exception as a:
		print a

while(True):
	fc=0
	fl=os.listdir("/home/cool/project18/trigger/file_ack/")
	fc=len(fl)		
	print "Total no of files present in file_ack dir "+str(fc)
	
	if fc>0:
		db = MySQLdb.connect("localhost","root","password","saas")
		cursor = db.cursor()
		for i in fl:
			with open("/home/cool/project18/trigger/file_ack/"+str(i),'r') as f:
				con=f.read()
			fields=con.split("\t")
			print fields
			fname=fields[0]
			
			if(fname=='Error'):
				print 'Error acknowledgement has arrived'
				fname=fields[1]
				mac=fields[2]
				uname=fields[3]
				fid=fields[4]
				print 'file for which error was generated is: ',fname
				print 'node which is unreachable is: ',mac
				print 'waiting for a while for path update to be taken'
				time.sleep(15)
				print "filename is: ",fname
				oldpath=readoldfilepath(fname)
				print "oldpath: ",oldpath
				dbpath=getpathfromdb(mac)
				print "dbpath: ",dbpath
				if(oldpath==dbpath):
					print "path was not updated need to get new node"
					path=getnewnode(mac,fid)
					retrywithnewpath(fname,path,fields[3],fields[4])
					
				else:	
					print "path was updated need to retry with new path"				
					retrywithnewpath(fname,dbpath,fields[3],fields[4])
				os.remove("/home/cool/project18/trigger/file_ack/"+str(i))				

			else:			
				mac=fields[1]
				uname=fields[2]
				fid=fields[3]
				print "filename is: ",fname
				print "mac is: ",mac
				print "uname is: ",uname
				print "fid is: ",fid
				
			
				try:
					sql = "insert into file_part values("+str(fid)+",\""+str(fname)+"\""+",\""+str(mac)+"\");"
					print sql
					cursor.execute(sql)	
					db.commit()
					os.remove("/home/cool/project18/server/buffer/"+fname)
					os.remove("/home/cool/project18/trigger/file_ack/"+str(i))
					#os.remove("erasure/"+fname)
				except Exception as a:
					print a
		db.close()
	time.sleep(5)
